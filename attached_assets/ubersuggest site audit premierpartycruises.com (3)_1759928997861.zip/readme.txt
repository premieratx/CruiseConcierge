
  Difficulty:
Hard - Requires high technical knowledge to fix.
Moderate - Requires some technical knowledge to fix.
Easy - Requires little technical knowledge to fix.
  SEO Impact:
High - Critical issues that must be fixed. They have the greatest effect on traffic and rankings.
Medium - Issues that affect traffic and rankings, but are not putting a website in critical SEO danger.
Low - Recommended fixes based on best practices. They have the least effect on traffic and rankings.
1. Problem: Without a H1 heading
Report file: no_h1_heading.csv
Description: Search engine crawlers prefer content that is structured properly and has a hierarchy when it comes to heading tags. The H1 tag is the most important and tells search engines what it is your content is about. There should only be one H1 tag for each page.
Solution: Add an H1 tag to your pages that is relevant to the content you are posting. Try to include keywords in your H1 tag and limit each page to just one H1 tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. H1 count
2. Problem: Have a low word count
Report file: low_word_count.csv
Description: Without enough text on a page, Google will have trouble understanding what the content is about. 

If Google doesn't know what the content is about, it won't be able to rank your content for the search terms you are targeting. 

By adding more text, you are telling Google's crawlers, and your end users, more about what it is you have to offer. Anything less than a few hundred words is considered thin content and will be nearly impossible to rank.
Solution: Add more content to your page so that it isn't considered thin content and has a better chance of ranking. In general the average web page that ranks on page 1 of Google contains 2200 words.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Content count words
3. Problem: Have duplicate meta description tags
Report file: multiple_meta_descriptions.csv
Description: Having more than one meta description tag on a page makes it difficult for search engines to know what the content is about or if the content will be a good fit for people who are performing searches. Having only one meta description tag per page will give you a much better chance at ranking in search results.
Solution: Make sure that every page you post on your website has a unique meta description that is both relevant to the content on the page and one of a kind.

To learn more about how to write amazing meta descriptions that are both unique and compelling, check out {0} article.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Duplicate meta tags
4. Problem: With duplicate meta descriptions
Report file: duplicate_meta_descriptions.csv
Description: Meta descriptions are the small blurbs you see in search results under the page titles. These give a quick description of what the content on the page is about. These descriptions help both the people searching and the search engine crawlers understand what to expect on each page.

Avoiding duplicate meta descriptions is important as it ensures visitors will be accessing unique information. Having duplicate meta descriptions can make the ranking process more difficult as engine crawlers will have a hard time figuring out the differences between pages and what should rank and what shouldn't.
Solution: Make sure that every page you post on your website has a meta description that is both relevant to the content on the page and one of a kind.

To learn more about how to write amazing meta descriptions that are both unique and compelling, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have meta description duplicates
5. Problem: With duplicate <title> tags
Report file: duplicate_title_tags.csv
Description: It's very important that each of your pages have original and unique title tags. Duplicate title tags can make it more complicated to rank content in search results because search engine crawlers won't know which post to rank above the other. If you want to rank your pages without confusion or without having them compete with one another, creating unique and relevant title tags is incredibly important.
Solution: Go through your pages and make sure that all of the title tags are unique and that you don't have any duplicate title tags.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have title duplicates
7. Problem: With no meta description
Report file: no_meta_description.csv
Description: Meta descriptions can significantly increase the chance of someone clicking on your content in the search results. The meta description lets people know what to expect on the page they are about to open. If you choose not to add an optimized and intriguing meta description, the search engine will typically add the first sentence of the page. Usually, that will not be enough to pique the interest of the person searching and they might not click.
Solution: Go through your site content and add relevant and unique meta descriptions to each page to increase your chances of intriguing searchers to click through to your content. 

To learn about writing an effective meta description, check out {0} article.
Difficulty: Moderate
SEO Impact: Medium
Columns:
    1. URL
    2. Meta description length
9. Problem: With a long loading time
Report file: long_load_time.csv
Description: The load time of a website refers to the time that it takes for the entire site to render in your browser, displaying all parts of the site's HTML code. This does not include images, CSS, Java, or any other non-HTML codes. 

Never has it been more important for your site's load time to happen quickly. If you want your content to rank, it's vital that your site loads quickly. The faster the better.
Solution: Ensure that your website's HTML code is clean and uncluttered. Removing unnecessary plugins, elements, or features can help with load speed. Make sure that you are compressing images and caching. If your server is compromising your load speed, consider upgrading to a better hosting company or a more robust plan.
Difficulty: Hard
SEO Impact: High
Columns:
    1. URL
    2. Time total load
10. Problem: With a <title> tag that is too long
Report file: title_tag_too_long.csv
Description: It is recommended to keep your title tag under 65 characters so you don't run the risk of having part of it cut out from the search results page.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Go through your pages and shorten any of your title tags that exceed 65 characters.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title long
11. Problem: With a poorly formatted URL for SEO
Report file: seo_non_friendly_url.csv
Description: In order to create a URL that is truly SEO-friendly, one must take into account certain factors that Google deems important for rankings. Some of these factors include the length of the URL not exceeding 120 characters, how relevant the wording in the title is to the content in the post, avoiding symbols and underscores within the slug, inclusion of session IDs, too many different sub-folders, and so on.

To learn more about SEO-friendly URLs, check out {0} article.
Solution: Avoid overcomplicating your URL structure by only focusing on using keywords in your slug that are relevant to the content in the post. Your URL should only contain numbers, letters, and dashes, and you should avoid using extraneous characters such as: !, @, #, $, %, ^, &, *, (, ), [, ], ?, {, }, ;, :, “.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url
12. Problem: Characters check
Report file: seo_friendly_url_characters_check.csv
Description: <b>Characters Check</b> - the tool will be checking for symbols in accordance with Google recommendations. Basically, your URLs should only contain uppercase and lowercase Latin characters, digits and dashes.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url characters check
13. Problem: Dynamic check
Report file: seo_friendly_url_dynamic_check.csv
Description: <b>Dynamic Check</b> - Ubersuggest will be looking for the presence of dynamic parameters in your URLs such as in the example ‘https://example.com/some_url.php?adsasd=5’ - all these dynamic characters like questions marks, equal signs, anything that isn't 'readable' by a human will be identified as dynamic.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url dynamic check
14. Problem: Keywords check
Report file: seo_friendly_url_keywords_check.csv
Description: <b>Keywords Check</b> - This test will be looking for the consistency of page URL with meta tag keywords. If the keywords tag is empty or absent then the URL is being compared with the content of &lt;title&gt; tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url keywords check
