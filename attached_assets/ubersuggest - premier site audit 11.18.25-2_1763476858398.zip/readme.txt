
  Difficulty:
Hard - Requires high technical knowledge to fix.
Moderate - Requires some technical knowledge to fix.
Easy - Requires little technical knowledge to fix.
  SEO Impact:
High - Critical issues that must be fixed. They have the greatest effect on traffic and rankings.
Medium - Issues that affect traffic and rankings, but are not putting a website in critical SEO danger.
Low - Recommended fixes based on best practices. They have the least effect on traffic and rankings.
1. Problem: Without a valid SSL certificate
Report file: no_valid_ssl_certificate.csv
Description: SSL certificates are digital certificates that enable an encrypted connection and authenticate a website. They provide your visitors with the reassurance that they will have a safe connection between your site and their device. Moving from http to https on your site is now considered to be something that can help boost your rankings as it provides a more secure, and therefore better, experience to your end user.
Solution: To learn more about SSL certificates and how to implement them on your site, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Ssl certificate valid
2. Problem: Without a H1 heading
Report file: no_h1_heading.csv
Description: Search engine crawlers prefer content that is structured properly and has a hierarchy when it comes to heading tags. The H1 tag is the most important and tells search engines what it is your content is about. There should only be one H1 tag for each page.
Solution: Add an H1 tag to your pages that is relevant to the content you are posting. Try to include keywords in your H1 tag and limit each page to just one H1 tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. H1 count
3. Problem: Have a low word count
Report file: low_word_count.csv
Description: Without enough text on a page, Google will have trouble understanding what the content is about. 

If Google doesn't know what the content is about, it won't be able to rank your content for the search terms you are targeting. 

By adding more text, you are telling Google's crawlers, and your end users, more about what it is you have to offer. Anything less than a few hundred words is considered thin content and will be nearly impossible to rank.
Solution: Add more content to your page so that it isn't considered thin content and has a better chance of ranking. In general the average web page that ranks on page 1 of Google contains 2200 words.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Content count words
4. Problem: With duplicate meta descriptions
Report file: duplicate_meta_descriptions.csv
Description: Meta descriptions are the small blurbs you see in search results under the page titles. These give a quick description of what the content on the page is about. These descriptions help both the people searching and the search engine crawlers understand what to expect on each page.

Avoiding duplicate meta descriptions is important as it ensures visitors will be accessing unique information. Having duplicate meta descriptions can make the ranking process more difficult as engine crawlers will have a hard time figuring out the differences between pages and what should rank and what shouldn't.
Solution: Make sure that every page you post on your website has a meta description that is both relevant to the content on the page and one of a kind.

To learn more about how to write amazing meta descriptions that are both unique and compelling, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have meta description duplicates
5. Problem: With duplicate <title> tags
Report file: duplicate_title_tags.csv
Description: It's very important that each of your pages have original and unique title tags. Duplicate title tags can make it more complicated to rank content in search results because search engine crawlers won't know which post to rank above the other. If you want to rank your pages without confusion or without having them compete with one another, creating unique and relevant title tags is incredibly important.
Solution: Go through your pages and make sure that all of the title tags are unique and that you don't have any duplicate title tags.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have title duplicates
6. Problem: With a <title> tag that is too long
Report file: title_tag_too_long.csv
Description: It is recommended to keep your title tag under 65 characters so you don't run the risk of having part of it cut out from the search results page.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Go through your pages and shorten any of your title tags that exceed 65 characters.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title long
7. Problem: With a <title> tag that is too short
Report file: title_tag_too_short.csv
Description: Title tags need to deliver an important idea to your potential readers in a few words. But the title tag can't be too short. If the title tag is less than 30 characters, it will be difficult for search engines to understand what the content is about and decreasing the likelihood of ranking.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Title tags need to deliver an important idea to your potential readers in a few words. But the title tag can't be too short. If the title tag is less than 30 characters, it will be difficult for search engines to understand what the content is about and decreasing the likelihood of ranking.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title length
8. Problem: With a poorly formatted URL for SEO
Report file: seo_non_friendly_url.csv
Description: In order to create a URL that is truly SEO-friendly, one must take into account certain factors that Google deems important for rankings. Some of these factors include the length of the URL not exceeding 120 characters, how relevant the wording in the title is to the content in the post, avoiding symbols and underscores within the slug, inclusion of session IDs, too many different sub-folders, and so on.

To learn more about SEO-friendly URLs, check out {0} article.
Solution: Avoid overcomplicating your URL structure by only focusing on using keywords in your slug that are relevant to the content in the post. Your URL should only contain numbers, letters, and dashes, and you should avoid using extraneous characters such as: !, @, #, $, %, ^, &, *, (, ), [, ], ?, {, }, ;, :, “.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url
9. Problem: Keywords check
Report file: seo_friendly_url_keywords_check.csv
Description: <b>Keywords Check</b> - This test will be looking for the consistency of page URL with meta tag keywords. If the keywords tag is empty or absent then the URL is being compared with the content of &lt;title&gt; tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url keywords check
